#!/bin/bash
#
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#              d-hh:mm:ss
#SBATCH --time=0-12:00:00

export TMP=/tmp
export TEMP=/tmp
export TMPDIR=/tmp
## Load modules for qdynp
module load 2023 iimpi/2023a

## define qdynp location
qdyn=/home/wjespers/software/Q/bin/qdynp
fepfiles=(FEP4.fep)
temperature=298
run=10
finalMDrestart=md_0000_1000.re

workdir=/data1/s2904160/software_qligfep/indene_softcore_both_directions/protein_leg
inputfiles=/data1/s2904160/software_qligfep/indene_softcore_both_directions/protein_leg/inputfiles2
fepfile=FEP4.fep
fepdir=$workdir/FEP4
mkdir -p $fepdir
cd $fepdir
tempdir=$fepdir/$temperature
mkdir -p $tempdir
cd $tempdir

rundir=$tempdir/$run
mkdir -p $rundir
cd $rundir

cp $inputfiles/md*.inp .
cp $inputfiles/*.top .
cp $inputfiles/qfep4.inp .
cp $inputfiles/$fepfile .

lastfep=FEP3
cp $workdir/$lastfep/$temperature/$run/$finalMDrestart $rundir/eq5.re

sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp

#EQ_FILES

#RUN_FILES
time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log
time mpirun -np 16 $qdyn md_0750_0250.inp > md_0750_0250.log
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log
time mpirun -np 16 $qdyn md_0250_0750.inp > md_0250_0750.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log

timeout 30s /home/wjespers/software/Q/bin/qfep < qfep4.inp > qfep4.out
done
