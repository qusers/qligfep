import os

directories = os.listdir('.')

for dirrr in directories:
    if os.path.isdir(dirrr):
        directories2 = os.listdir(dirrr + "/inputfiles")
        for file in directories2:
            # print(file)
            if file == 'runSNELLIUS.sh':
                # print('yes')
                newfilelines = []
                with open(dirrr + "/inputfiles/" + file) as mdfile:
                    for mdfile_lines in mdfile:
                        if "/home/wjespers/software/Q/bin/qdynp" in mdfile_lines:
                           # print(mdfile_lines)
                           # print("yes")
                            # print(mdfile_lines[:-2] + "1\n")
                            newfilelines.append(mdfile_lines.replace("/home/wjespers/software/Q/bin/qdynp", "/home/wjespers/software/Q_old/Q/bin/qdynp"))
                           # print(mdfile_lines.replace("/home/wjespers/software/Q/bin/qdynp", "/home/wjespers/software/Q_old/Q/bin/qdynp"))
                        elif "timeout" in mdfile_lines:
                            newfilelines.append(mdfile_lines.replace("/home/wjespers/software/Q/bin/qfep", "/home/wjespers/software/Q_old/Q/bin/qfep"))
                        else:
                            newfilelines.append(mdfile_lines)
                   # print(newfilelines)
                with open(dirrr + "/inputfiles/runSNELLIUS.sh", 'w') as new:
                    for line in newfilelines:
                        new.write(line)