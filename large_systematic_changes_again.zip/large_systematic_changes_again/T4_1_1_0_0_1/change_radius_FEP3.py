import os

directories = os.listdir('.')

# inputs = []

# for dirr in directories:
#     if dirr[:2] == 'md':
#         dirrr = dirr.strip('inp') + 'en'
#         inputs.append(dirrr)

# for i in reversed(inputs):
    # print(i)
    # print('time mpirun -np 16 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))
for dirrr in directories:
    if os.path.isdir(dirrr):
        directories2 = os.listdir(dirrr + "/inputfiles/mdfiles3")
        for file in directories2:
            if file[:2] == 'md':
                newfilelines = []
                with open(dirrr + "/inputfiles/mdfiles3/" + file) as mdfile:
                    for mdfile_lines in mdfile:
                        if 'shell_radius' in mdfile_lines:
                            newfilelines.append("shell_radius              15\n")
                        else:
                            newfilelines.append(mdfile_lines)

            with open(dirrr + "/inputfiles/mdfiles3/" + file, 'w') as new:
                for line in newfilelines:
                    new.write(line)
