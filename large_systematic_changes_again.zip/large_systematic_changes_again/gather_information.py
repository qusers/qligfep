import glob
import statistics
# import pandas
import argparse
import os

folder_to_retreive_information_from = "T4_0_0_0_0_1"

directories = os.listdir(folder_to_retreive_information_from)

# os.mkdir("gathered_data_" + folder_to_retreive_information_from)

for dirr in directories:
    if os.path.isdir(os.getcwd() + "/" + folder_to_retreive_information_from + "/" + dirr):
        slurm = glob.glob(os.getcwd() + "/" + folder_to_retreive_information_from + "/" + dirr + "/slurm*.out")
        with open(slurm[0], 'r') as slurmdata, open(folder_to_retreive_information_from + '_results.txt', 'a+') as output_file:
            output_file.write(dirr + "\n")
            for line in slurmdata:
                if "STOP qprep ended normally" in line:
                    continue
                if "JOB STATISTICS" in line:
                    break
                else:
                    output_file.write(line)