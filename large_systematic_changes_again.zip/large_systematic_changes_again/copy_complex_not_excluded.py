/gpfs/scratch1/nodespecific/int6/yricky/large_systematic_changes

import glob
import statistics
# import pandas
import argparse
import os

folder_to_retreive_information_from = "T4_0_0_0_0_1"
directories_2 = os.listdir(folder_to_retreive_information_from)

folder_to_copy_from = {}
directories = os.listdir("/gpfs/scratch1/nodespecific/int6/yricky/large_systematic_changes/T4_0_0_0_0_1")

for folder in directories:
    if os.path.isdir("/gpfs/scratch1/nodespecific/int6/yricky/large_systematic_changes/T4_0_0_0_0_1/" + folder):
        folder_to_copy_from[folder] = "/gpfs/scratch1/nodespecific/int6/yricky/large_systematic_changes/T4_0_0_0_0_1/" + folder

for dirr in directories_2:
    # print(os.getcwd() + "/" + folder_to_retreive_information_from + "/" + dirr)
    if os.path.isdir(os.getcwd() + "/" + folder_to_retreive_information_from + "/" + dirr):
        