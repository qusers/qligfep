import os

directories = os.listdir('.')

# inputs = []

# for dirr in directories:
#     if dirr[:2] == 'md':
#         dirrr = dirr.strip('inp') + 'en'
#         inputs.append(dirrr)

# for i in reversed(inputs):
    # print(i)
    # print('time mpirun -np 16 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))

def restraint(mdfile, restraints):
    if mdfile == 240 or mdfile == 260:
        restraint = restraints + '4.0 0  0\n'
        # print(1)
    elif mdfile == 200 or mdfile == 220:
        restraint = restraints + '3.0 0  0\n'
        # print(2)
    elif mdfile == 160 or mdfile == 180:
        restraint = restraints + '2.0 0  0\n'
        # print(3)
    elif mdfile == 120 or mdfile == 140:
        restraint = restraints + '1.0 0  0\n'
        # print(4)
    elif mdfile < 100:
        restraint = '\n'
    else:
        restraint = restraints + '5.0 0  0\n'
    return restraint

for dirrr in directories:
    if os.path.isdir(dirrr):
        directories2 = os.listdir(dirrr + "/inputfiles/mdfiles3")
        for file in directories2:
            if file[:2] == 'md':
                newfilelines = []
                with open(dirrr + "/inputfiles/mdfiles3/" + file) as mdfile:
                    for mdfile_lines in mdfile:
                        if mdfile_lines[:4] == '2597':
                            # print(int(file[4:7]))
                            # print(mdfile_lines[:-9])
                            restr = restraint(int(file[4:7]), mdfile_lines[:-9])
                            print(restr)
                            # print(mdfile_lines)
                            # print(mdfile_lines[:-2] + "1\n")
                            newfilelines.append(newfilelines.append(restr))
                        else:
                            newfilelines.append(mdfile_lines)

            with open(dirrr + "/inputfiles/mdfiles3/" + file, 'w') as new:
                for line in newfilelines:
                    new.write(line)

# import os

# directories = os.listdir('.')

# # inputs = []

# # for dirr in directories:
# #     if dirr[:2] == 'md':
# #         dirrr = dirr.strip('inp') + 'en'
# #         inputs.append(dirrr)

# # for i in reversed(inputs):
# #     print(i)
#     # print('time mpirun -np 24 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))



# for dirr in directories:
#     start = 0
#     # print(dirr)
#     if dirr[:2] == 'md':
#         newfilelines = []
#         with open(dirr) as mdfile:
#                 # print(restraint)
#             for line in mdfile:
#                 # newfilelines.append(line)
#                 if '[sequence_restraints]' in line:
#                     restr = restraint(int(dirr[4:7]))
#                     print(restr)
#                     # print(restr)
#                     newfilelines.append(line)
#                     newfilelines.append(restr)
#                     # newfilelines.append('[distance_restraints]\n')
#                     break
#                 else:
#                     newfilelines.append(line)

#             with open(dirr, 'w') as new:
#                 for line in newfilelines:
#                     new.write(line)