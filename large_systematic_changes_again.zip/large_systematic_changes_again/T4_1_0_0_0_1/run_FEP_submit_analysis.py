import os
import subprocess
import glob

directories = os.listdir('.')

for dirr in directories:
    if os.path.isdir(dirr):
        files_in_dir = os.listdir(dirr)
        os.chdir(dirr)
        cwd = os.getcwd()
        slurms = glob.glob(cwd + "/slurm*.out")
        if slurms != []:
            for slurmfile in slurms:
                os.remove(slurmfile)
        if "FEP_submit_analysis.sh" in files_in_dir:
            subprocess.call(['sh', 'FEP_submit_analysis.sh'])
            os.chdir("..")