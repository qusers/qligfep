import glob
import statistics
# import pandas
import argparse
import os
import shutil

folder_to_retreive_information_from = "T4_0_0_0_0_1"

directories = os.listdir(folder_to_retreive_information_from)

# os.mkdir("gathered_data_" + folder_to_retreive_information_from)

for dirr in directories:
    os.mkdir(folder_to_retreive_information_from + "_trajectories")
    if os.path.isdir(os.getcwd() + "/" + folder_to_retreive_information_from + "/" + dirr):
        os.mkdir(folder_to_retreive_information_from + "_trajectories/" + dirr)
        for index in range(1,11):
            shutil.copy2(os.getcwd() + "/" + folder_to_retreive_information_from + "/" + dirr + "/FEP1/298/" + str(index) + "/trajectory.pdb",\
            folder_to_retreive_information_from + "_trajectories/" + dirr + "/FEP1_" + str(index))
            shutil.copy2(os.getcwd() + "/" + folder_to_retreive_information_from + "/" + dirr + "/FEP2/298/" + str(index) + "/trajectory.pdb",\
            folder_to_retreive_information_from + "_trajectories/" + dirr + "/FEP2_" + str(index))
            shutil.copy2(os.getcwd() + "/" + folder_to_retreive_information_from + "/" + dirr + "/FEP3/298/" + str(index) + "/trajectory.pdb",\
            folder_to_retreive_information_from + "_trajectories/" + dirr + "/FEP3_" + str(index))