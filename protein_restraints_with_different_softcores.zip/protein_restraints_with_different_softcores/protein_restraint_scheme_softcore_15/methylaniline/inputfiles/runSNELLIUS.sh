#!/bin/bash
#
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#              d-hh:mm:ss
#SBATCH --time=0-12:00:00

export TMP=/tmp
export TEMP=/tmp
export TMPDIR=/tmp
## Load modules for qdynp
module load 2023 iimpi/2023a


vdW_leg() {
local index=$1
cp $inputfiles/mdfiles$index/eq*.inp .
sed -i s/SEED_VAR/"$[1 + $[RANDOM % 9999]]"/ eq1.inp
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp
#EQ_FILES
time mpirun -np 16 $qdyn eq1.inp > eq1.log
time mpirun -np 16 $qdyn eq2.inp > eq2.log
time mpirun -np 16 $qdyn eq3.inp > eq3.log
time mpirun -np 16 $qdyn eq4.inp > eq4.log
time mpirun -np 16 $qdyn eq5.inp > eq5.log

#RUN_FILES
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log
time mpirun -np 16 $qdyn md_0510_0490.inp > md_0510_0490.log
time mpirun -np 16 $qdyn md_0520_0480.inp > md_0520_0480.log
time mpirun -np 16 $qdyn md_0530_0470.inp > md_0530_0470.log
time mpirun -np 16 $qdyn md_0540_0460.inp > md_0540_0460.log
time mpirun -np 16 $qdyn md_0550_0450.inp > md_0550_0450.log
time mpirun -np 16 $qdyn md_0560_0440.inp > md_0560_0440.log
time mpirun -np 16 $qdyn md_0570_0430.inp > md_0570_0430.log
time mpirun -np 16 $qdyn md_0580_0420.inp > md_0580_0420.log
time mpirun -np 16 $qdyn md_0590_0410.inp > md_0590_0410.log
time mpirun -np 16 $qdyn md_0600_0400.inp > md_0600_0400.log
time mpirun -np 16 $qdyn md_0610_0390.inp > md_0610_0390.log
time mpirun -np 16 $qdyn md_0620_0380.inp > md_0620_0380.log
time mpirun -np 16 $qdyn md_0630_0370.inp > md_0630_0370.log
time mpirun -np 16 $qdyn md_0640_0360.inp > md_0640_0360.log
time mpirun -np 16 $qdyn md_0650_0350.inp > md_0650_0350.log
time mpirun -np 16 $qdyn md_0660_0340.inp > md_0660_0340.log
time mpirun -np 16 $qdyn md_0670_0330.inp > md_0670_0330.log
time mpirun -np 16 $qdyn md_0680_0320.inp > md_0680_0320.log
time mpirun -np 16 $qdyn md_0690_0310.inp > md_0690_0310.log
time mpirun -np 16 $qdyn md_0700_0300.inp > md_0700_0300.log
time mpirun -np 16 $qdyn md_0710_0290.inp > md_0710_0290.log
time mpirun -np 16 $qdyn md_0720_0280.inp > md_0720_0280.log
time mpirun -np 16 $qdyn md_0730_0270.inp > md_0730_0270.log
time mpirun -np 16 $qdyn md_0740_0260.inp > md_0740_0260.log
time mpirun -np 16 $qdyn md_0750_0250.inp > md_0750_0250.log
time mpirun -np 16 $qdyn md_0760_0240.inp > md_0760_0240.log
time mpirun -np 16 $qdyn md_0770_0230.inp > md_0770_0230.log
time mpirun -np 16 $qdyn md_0780_0220.inp > md_0780_0220.log
time mpirun -np 16 $qdyn md_0790_0210.inp > md_0790_0210.log
time mpirun -np 16 $qdyn md_0800_0200.inp > md_0800_0200.log
time mpirun -np 16 $qdyn md_0810_0190.inp > md_0810_0190.log
time mpirun -np 16 $qdyn md_0820_0180.inp > md_0820_0180.log
time mpirun -np 16 $qdyn md_0830_0170.inp > md_0830_0170.log
time mpirun -np 16 $qdyn md_0840_0160.inp > md_0840_0160.log
time mpirun -np 16 $qdyn md_0850_0150.inp > md_0850_0150.log
time mpirun -np 16 $qdyn md_0860_0140.inp > md_0860_0140.log
time mpirun -np 16 $qdyn md_0870_0130.inp > md_0870_0130.log
time mpirun -np 16 $qdyn md_0880_0120.inp > md_0880_0120.log
time mpirun -np 16 $qdyn md_0890_0110.inp > md_0890_0110.log
time mpirun -np 16 $qdyn md_0900_0100.inp > md_0900_0100.log
time mpirun -np 16 $qdyn md_0905_0095.inp > md_0905_0095.log
time mpirun -np 16 $qdyn md_0910_0090.inp > md_0910_0090.log
time mpirun -np 16 $qdyn md_0915_0085.inp > md_0915_0085.log
time mpirun -np 16 $qdyn md_0919_0081.inp > md_0919_0081.log
time mpirun -np 16 $qdyn md_0923_0077.inp > md_0923_0077.log
time mpirun -np 16 $qdyn md_0927_0073.inp > md_0927_0073.log
time mpirun -np 16 $qdyn md_0931_0069.inp > md_0931_0069.log
time mpirun -np 16 $qdyn md_0935_0065.inp > md_0935_0065.log
time mpirun -np 16 $qdyn md_0939_0061.inp > md_0939_0061.log
time mpirun -np 16 $qdyn md_0942_0058.inp > md_0942_0058.log
time mpirun -np 16 $qdyn md_0945_0055.inp > md_0945_0055.log
time mpirun -np 16 $qdyn md_0948_0052.inp > md_0948_0052.log
time mpirun -np 16 $qdyn md_0951_0049.inp > md_0951_0049.log
time mpirun -np 16 $qdyn md_0954_0046.inp > md_0954_0046.log
time mpirun -np 16 $qdyn md_0957_0043.inp > md_0957_0043.log
time mpirun -np 16 $qdyn md_0960_0040.inp > md_0960_0040.log
time mpirun -np 16 $qdyn md_0962_0038.inp > md_0962_0038.log
time mpirun -np 16 $qdyn md_0964_0036.inp > md_0964_0036.log
time mpirun -np 16 $qdyn md_0966_0034.inp > md_0966_0034.log
time mpirun -np 16 $qdyn md_0968_0032.inp > md_0968_0032.log
time mpirun -np 16 $qdyn md_0970_0030.inp > md_0970_0030.log
time mpirun -np 16 $qdyn md_0972_0028.inp > md_0972_0028.log
time mpirun -np 16 $qdyn md_0974_0026.inp > md_0974_0026.log
time mpirun -np 16 $qdyn md_0976_0024.inp > md_0976_0024.log
time mpirun -np 16 $qdyn md_0978_0022.inp > md_0978_0022.log
time mpirun -np 16 $qdyn md_0980_0020.inp > md_0980_0020.log
time mpirun -np 16 $qdyn md_0981_0019.inp > md_0981_0019.log
time mpirun -np 16 $qdyn md_0982_0018.inp > md_0982_0018.log
time mpirun -np 16 $qdyn md_0983_0017.inp > md_0983_0017.log
time mpirun -np 16 $qdyn md_0984_0016.inp > md_0984_0016.log
time mpirun -np 16 $qdyn md_0985_0015.inp > md_0985_0015.log
time mpirun -np 16 $qdyn md_0986_0014.inp > md_0986_0014.log
time mpirun -np 16 $qdyn md_0987_0013.inp > md_0987_0013.log
time mpirun -np 16 $qdyn md_0988_0012.inp > md_0988_0012.log
time mpirun -np 16 $qdyn md_0989_0011.inp > md_0989_0011.log
time mpirun -np 16 $qdyn md_0990_0010.inp > md_0990_0010.log
time mpirun -np 16 $qdyn md_0991_0009.inp > md_0991_0009.log
time mpirun -np 16 $qdyn md_0992_0008.inp > md_0992_0008.log
time mpirun -np 16 $qdyn md_0993_0007.inp > md_0993_0007.log
time mpirun -np 16 $qdyn md_0994_0006.inp > md_0994_0006.log
time mpirun -np 16 $qdyn md_0995_0005.inp > md_0995_0005.log
time mpirun -np 16 $qdyn md_0996_0004.inp > md_0996_0004.log
time mpirun -np 16 $qdyn md_0997_0003.inp > md_0997_0003.log
time mpirun -np 16 $qdyn md_0998_0002.inp > md_0998_0002.log
time mpirun -np 16 $qdyn md_0999_0001.inp > md_0999_0001.log
time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log

time mpirun -np 16 $qdyn md_0480_0520.inp > md_0480_0520.log
time mpirun -np 16 $qdyn md_0460_0540.inp > md_0460_0540.log
time mpirun -np 16 $qdyn md_0440_0560.inp > md_0440_0560.log
time mpirun -np 16 $qdyn md_0420_0580.inp > md_0420_0580.log
time mpirun -np 16 $qdyn md_0400_0600.inp > md_0400_0600.log
time mpirun -np 16 $qdyn md_0380_0620.inp > md_0380_0620.log
time mpirun -np 16 $qdyn md_0360_0640.inp > md_0360_0640.log
time mpirun -np 16 $qdyn md_0340_0660.inp > md_0340_0660.log
time mpirun -np 16 $qdyn md_0320_0680.inp > md_0320_0680.log
time mpirun -np 16 $qdyn md_0300_0700.inp > md_0300_0700.log
time mpirun -np 16 $qdyn md_0280_0720.inp > md_0280_0720.log
time mpirun -np 16 $qdyn md_0260_0740.inp > md_0260_0740.log
time mpirun -np 16 $qdyn md_0240_0760.inp > md_0240_0760.log
time mpirun -np 16 $qdyn md_0220_0780.inp > md_0220_0780.log
time mpirun -np 16 $qdyn md_0200_0800.inp > md_0200_0800.log
time mpirun -np 16 $qdyn md_0180_0820.inp > md_0180_0820.log
time mpirun -np 16 $qdyn md_0160_0840.inp > md_0160_0840.log
time mpirun -np 16 $qdyn md_0140_0860.inp > md_0140_0860.log
time mpirun -np 16 $qdyn md_0120_0880.inp > md_0120_0880.log
time mpirun -np 16 $qdyn md_0100_0900.inp > md_0100_0900.log
time mpirun -np 16 $qdyn md_0080_0920.inp > md_0080_0920.log
time mpirun -np 16 $qdyn md_0060_0940.inp > md_0060_0940.log
time mpirun -np 16 $qdyn md_0040_0960.inp > md_0040_0960.log
time mpirun -np 16 $qdyn md_0020_0980.inp > md_0020_0980.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log

timeout 30s /home/wjespers/software/Q/bin/qfep < qfep1.inp > qfep1.out
}

softcore_leg() {
local index=$1
lastfep=FEP$((index-1))
cp $workdir/$lastfep/$temperature/$run/$finalMDrestart $rundir/eq5.re
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp
#RUN_FILES
time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log
time mpirun -np 16 $qdyn md_0980_0020.inp > md_0980_0020.log
time mpirun -np 16 $qdyn md_0960_0040.inp > md_0960_0040.log
time mpirun -np 16 $qdyn md_0940_0060.inp > md_0940_0060.log
time mpirun -np 16 $qdyn md_0920_0080.inp > md_0920_0080.log
time mpirun -np 16 $qdyn md_0900_0100.inp > md_0900_0100.log
time mpirun -np 16 $qdyn md_0880_0120.inp > md_0880_0120.log
time mpirun -np 16 $qdyn md_0860_0140.inp > md_0860_0140.log
time mpirun -np 16 $qdyn md_0840_0160.inp > md_0840_0160.log
time mpirun -np 16 $qdyn md_0820_0180.inp > md_0820_0180.log
time mpirun -np 16 $qdyn md_0800_0200.inp > md_0800_0200.log
time mpirun -np 16 $qdyn md_0780_0220.inp > md_0780_0220.log
time mpirun -np 16 $qdyn md_0760_0240.inp > md_0760_0240.log
time mpirun -np 16 $qdyn md_0740_0260.inp > md_0740_0260.log
time mpirun -np 16 $qdyn md_0720_0280.inp > md_0720_0280.log
time mpirun -np 16 $qdyn md_0700_0300.inp > md_0700_0300.log
time mpirun -np 16 $qdyn md_0680_0320.inp > md_0680_0320.log
time mpirun -np 16 $qdyn md_0660_0340.inp > md_0660_0340.log
time mpirun -np 16 $qdyn md_0640_0360.inp > md_0640_0360.log
time mpirun -np 16 $qdyn md_0620_0380.inp > md_0620_0380.log
time mpirun -np 16 $qdyn md_0600_0400.inp > md_0600_0400.log
time mpirun -np 16 $qdyn md_0580_0420.inp > md_0580_0420.log
time mpirun -np 16 $qdyn md_0560_0440.inp > md_0560_0440.log
time mpirun -np 16 $qdyn md_0540_0460.inp > md_0540_0460.log
time mpirun -np 16 $qdyn md_0520_0480.inp > md_0520_0480.log
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log
time mpirun -np 16 $qdyn md_0480_0520.inp > md_0480_0520.log
time mpirun -np 16 $qdyn md_0460_0540.inp > md_0460_0540.log
time mpirun -np 16 $qdyn md_0440_0560.inp > md_0440_0560.log
time mpirun -np 16 $qdyn md_0420_0580.inp > md_0420_0580.log
time mpirun -np 16 $qdyn md_0400_0600.inp > md_0400_0600.log
time mpirun -np 16 $qdyn md_0380_0620.inp > md_0380_0620.log
time mpirun -np 16 $qdyn md_0360_0640.inp > md_0360_0640.log
time mpirun -np 16 $qdyn md_0340_0660.inp > md_0340_0660.log
time mpirun -np 16 $qdyn md_0320_0680.inp > md_0320_0680.log
time mpirun -np 16 $qdyn md_0300_0700.inp > md_0300_0700.log
time mpirun -np 16 $qdyn md_0280_0720.inp > md_0280_0720.log
time mpirun -np 16 $qdyn md_0260_0740.inp > md_0260_0740.log
time mpirun -np 16 $qdyn md_0240_0760.inp > md_0240_0760.log
time mpirun -np 16 $qdyn md_0220_0780.inp > md_0220_0780.log
time mpirun -np 16 $qdyn md_0200_0800.inp > md_0200_0800.log
time mpirun -np 16 $qdyn md_0180_0820.inp > md_0180_0820.log
time mpirun -np 16 $qdyn md_0160_0840.inp > md_0160_0840.log
time mpirun -np 16 $qdyn md_0140_0860.inp > md_0140_0860.log
time mpirun -np 16 $qdyn md_0120_0880.inp > md_0120_0880.log
time mpirun -np 16 $qdyn md_0100_0900.inp > md_0100_0900.log
time mpirun -np 16 $qdyn md_0080_0920.inp > md_0080_0920.log
time mpirun -np 16 $qdyn md_0060_0940.inp > md_0060_0940.log
time mpirun -np 16 $qdyn md_0040_0960.inp > md_0040_0960.log
time mpirun -np 16 $qdyn md_0020_0980.inp > md_0020_0980.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log
timeout 30s /home/wjespers/software/Q/bin/qfep < qfep2.inp > qfep2.out
}

charge_leg() {
local index=$1
lastfep=FEP$((index-1))
cp $workdir/$lastfep/$temperature/$run/$finalMDrestart $rundir/eq5.re
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp
#RUN_FILES
time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log
time mpirun -np 16 $qdyn md_0980_0020.inp > md_0980_0020.log
time mpirun -np 16 $qdyn md_0960_0040.inp > md_0960_0040.log
time mpirun -np 16 $qdyn md_0940_0060.inp > md_0940_0060.log
time mpirun -np 16 $qdyn md_0920_0080.inp > md_0920_0080.log
time mpirun -np 16 $qdyn md_0900_0100.inp > md_0900_0100.log
time mpirun -np 16 $qdyn md_0880_0120.inp > md_0880_0120.log
time mpirun -np 16 $qdyn md_0860_0140.inp > md_0860_0140.log
time mpirun -np 16 $qdyn md_0840_0160.inp > md_0840_0160.log
time mpirun -np 16 $qdyn md_0820_0180.inp > md_0820_0180.log
time mpirun -np 16 $qdyn md_0800_0200.inp > md_0800_0200.log
time mpirun -np 16 $qdyn md_0780_0220.inp > md_0780_0220.log
time mpirun -np 16 $qdyn md_0760_0240.inp > md_0760_0240.log
time mpirun -np 16 $qdyn md_0740_0260.inp > md_0740_0260.log
time mpirun -np 16 $qdyn md_0720_0280.inp > md_0720_0280.log
time mpirun -np 16 $qdyn md_0700_0300.inp > md_0700_0300.log
time mpirun -np 16 $qdyn md_0680_0320.inp > md_0680_0320.log
time mpirun -np 16 $qdyn md_0660_0340.inp > md_0660_0340.log
time mpirun -np 16 $qdyn md_0640_0360.inp > md_0640_0360.log
time mpirun -np 16 $qdyn md_0620_0380.inp > md_0620_0380.log
time mpirun -np 16 $qdyn md_0600_0400.inp > md_0600_0400.log
time mpirun -np 16 $qdyn md_0580_0420.inp > md_0580_0420.log
time mpirun -np 16 $qdyn md_0560_0440.inp > md_0560_0440.log
time mpirun -np 16 $qdyn md_0540_0460.inp > md_0540_0460.log
time mpirun -np 16 $qdyn md_0520_0480.inp > md_0520_0480.log
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log
time mpirun -np 16 $qdyn md_0480_0520.inp > md_0480_0520.log
time mpirun -np 16 $qdyn md_0460_0540.inp > md_0460_0540.log
time mpirun -np 16 $qdyn md_0440_0560.inp > md_0440_0560.log
time mpirun -np 16 $qdyn md_0420_0580.inp > md_0420_0580.log
time mpirun -np 16 $qdyn md_0400_0600.inp > md_0400_0600.log
time mpirun -np 16 $qdyn md_0380_0620.inp > md_0380_0620.log
time mpirun -np 16 $qdyn md_0360_0640.inp > md_0360_0640.log
time mpirun -np 16 $qdyn md_0340_0660.inp > md_0340_0660.log
time mpirun -np 16 $qdyn md_0320_0680.inp > md_0320_0680.log
time mpirun -np 16 $qdyn md_0300_0700.inp > md_0300_0700.log
time mpirun -np 16 $qdyn md_0280_0720.inp > md_0280_0720.log
time mpirun -np 16 $qdyn md_0260_0740.inp > md_0260_0740.log
time mpirun -np 16 $qdyn md_0240_0760.inp > md_0240_0760.log
time mpirun -np 16 $qdyn md_0220_0780.inp > md_0220_0780.log
time mpirun -np 16 $qdyn md_0200_0800.inp > md_0200_0800.log
time mpirun -np 16 $qdyn md_0180_0820.inp > md_0180_0820.log
time mpirun -np 16 $qdyn md_0160_0840.inp > md_0160_0840.log
time mpirun -np 16 $qdyn md_0140_0860.inp > md_0140_0860.log
time mpirun -np 16 $qdyn md_0120_0880.inp > md_0120_0880.log
time mpirun -np 16 $qdyn md_0100_0900.inp > md_0100_0900.log
time mpirun -np 16 $qdyn md_0080_0920.inp > md_0080_0920.log
time mpirun -np 16 $qdyn md_0060_0940.inp > md_0060_0940.log
time mpirun -np 16 $qdyn md_0040_0960.inp > md_0040_0960.log
time mpirun -np 16 $qdyn md_0020_0980.inp > md_0020_0980.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log
timeout 30s /home/wjespers/software/Q/bin/qfep < qfep3.inp > qfep3.out
}

## define qdynp location
qdyn=/home/wjespers/software/Q/bin/qdynp
fepfiles=("FEP1.fep" "FEP2.fep" "FEP3.fep")
temperature=298
run=10
finalMDrestart=md_0000_1000.re

workdir=/gpfs/scratch1/nodespecific/int6/yricky/softcore_with_long_endpoint_sampling/butylmethylaniline_flag_0_seq5_soft5_15_radius_eq_15
inputfiles=/gpfs/scratch1/nodespecific/int6/yricky/softcore_with_long_endpoint_sampling/butylmethylaniline_flag_0_seq5_soft5_15_radius_eq_15/inputfiles

for ((index=1; index<=${#fepfiles[@]}; index++)); do
# do this for every FEP file, use index in the list.

fepfile=FEP$index.fep
fepstep=FEP$index
fepdir=$workdir/FEP$index
mkdir -p $fepdir
cd $fepdir
tempdir=$fepdir/$temperature
mkdir -p $tempdir
cd $tempdir
mdfilesdir=$inputfiles/mdfiles$index
rundir=$tempdir/$run
mkdir -p $rundir
cd $rundir

cp $mdfilesdir/md*.inp .
cp $inputfiles/*.top .
cp $inputfiles/qfep$index.inp .
cp $inputfiles/$fepfile .

# Run the appropriate job function based on the filename
if [ "$fepstep" == "FEP1" ]; then
vdW_leg $index
elif [ "$fepstep" == "FEP2" ]; then
softcore_leg $index
elif [ "$fepstep" == "FEP3" ]; then
charge_leg $index
fi

cd /gpfs/scratch1/nodespecific/int6/yricky
python retreive_dG_BAR_and_restraints.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP1
python retreive_dG_BAR_and_restraints.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP2
python retreive_dG_BAR_and_restraints.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP3
python retreive_shellrestr.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP1
python retreive_shellrestr.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP2
python retreive_shellrestr.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP3
python retreive_total_restr.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP1
python retreive_total_restr.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP2
python retreive_total_restr.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP3
~/anaconda3/envs/QligFEP/bin/python check_angle.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP1 -I inputfiles_softcore_check/methylaniline -FF OPLS2005 -convert
~/anaconda3/envs/QligFEP/bin/python check_angle.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP2 -I inputfiles_softcore_check/methylaniline -FF OPLS2005 -convert
~/anaconda3/envs/QligFEP/bin/python check_angle.py -F protein_restraints_with_different_softcores/protein_restraint_scheme_softcore_15/methylaniline/FEP3 -I inputfiles_softcore_check/methylaniline -FF OPLS2005 -convert
done