import os

directories = os.listdir('.')

# inputs = []

# for dirr in directories:
#     if dirr[:2] == 'md':
#         dirrr = dirr.strip('inp') + 'en'
#         inputs.append(dirrr)

# for i in reversed(inputs):
    # print(i)
    # print('time mpirun -np 16 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))

for dirr in directories:
    # print(dirr)
    if dirr[0:7] == "mdfiles":
        for mdfiles in os.listdir(dirr):
            # print(mdfiles)

            if mdfiles[:2] == 'md' or mdfiles[:2] == "eq":
                newfilelines = []
                with open(dirr + "/" + mdfiles) as mdfile:
                    for line in mdfile:
                        # newfilelines.append(line)
                        if '[sequence_restraints]' in line:
                            if mdfiles[:3] == "eq1" or mdfiles[:3] == "eq2":
                                    newfilelines.append(line)
                                    newfilelines.append('2597   2614   10.0 0  0\n\n')
                                    newfilelines.append('[distance_restraints]\n')
                            else:
                                newfilelines.append(line)
                                newfilelines.append('\n\n')
                                newfilelines.append('[atom_restraints]\n')
                                newfilelines.append('2598 0.719 1.067 0.524 5. 5. 0 0\n')
                                newfilelines.append('2599 0.627 -0.094 1.232 5. 5. 0 0\n')
                                newfilelines.append('2600 0.135 1.160 -0.726 5. 5. 0 0\n')
                                newfilelines.append('2601 -0.096 -1.181 0.701 5. 5. 0 0\n')
                                newfilelines.append('2602 -0.627 0.099 -1.227 5. 5. 0 0\n')
                                newfilelines.append('2603 -0.757 -1.052 -0.503 5. 5. 0 0\n\n')
                                newfilelines.append('[distance_restraints]\n')
                            break
                        else:
                            newfilelines.append(line)

                    with open(dirr + "/" + mdfiles, 'w') as new:
                        for line in newfilelines:
                            new.write(line)
