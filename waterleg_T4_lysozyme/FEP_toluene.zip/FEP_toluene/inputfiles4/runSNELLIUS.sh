#!/bin/bash
#
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#              d-hh:mm:ss
#SBATCH --time=0-12:00:00

export TMP=/tmp
export TEMP=/tmp
export TMPDIR=/tmp
## Load modules for qdynp
module load 2023 iimpi/2023a

## define qdynp location
qdyn=/home/wjespers/software/Q/bin/qdynp
fepfiles=(FEP4.fep)
temperature=298
run=10
finalMDrestart=md_0000_1000.re

workdir=/home/jespers/adenosine/1.A1-A2A_selectivity/A1/5.FEP/holo
inputfiles=/home/jespers/adenosine/1.A1-A2A_selectivity/A1/5.FEP/holo/inputfiles
fepfile=FEP4.fep
fepdir=$workdir/FEP4
mkdir -p $fepdir
cd $fepdir
tempdir=$fepdir/$temperature
mkdir -p $tempdir
cd $tempdir

rundir=$tempdir/$run
mkdir -p $rundir
cd $rundir

cp $inputfiles/md*.inp .
cp $inputfiles/*.top .
cp $inputfiles/qfep.inp .
cp $inputfiles/$fepfile .

lastfep=FEP3
cp $workdir/$lastfep/$temperature/$run/$finalMDrestart $rundir/eq5.re

sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp

#EQ_FILES

#RUN_FILES
time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log
time mpirun -np 16 $qdyn md_0986_0014.inp > md_0986_0014.log
time mpirun -np 16 $qdyn md_0971_0029.inp > md_0971_0029.log
time mpirun -np 16 $qdyn md_0957_0043.inp > md_0957_0043.log
time mpirun -np 16 $qdyn md_0943_0057.inp > md_0943_0057.log
time mpirun -np 16 $qdyn md_0929_0071.inp > md_0929_0071.log
time mpirun -np 16 $qdyn md_0914_0086.inp > md_0914_0086.log
time mpirun -np 16 $qdyn md_0900_0100.inp > md_0900_0100.log
time mpirun -np 16 $qdyn md_0886_0114.inp > md_0886_0114.log
time mpirun -np 16 $qdyn md_0871_0128.inp > md_0871_0128.log
time mpirun -np 16 $qdyn md_0857_0143.inp > md_0857_0143.log
time mpirun -np 16 $qdyn md_0843_0157.inp > md_0843_0157.log
time mpirun -np 16 $qdyn md_0828_0171.inp > md_0828_0171.log
time mpirun -np 16 $qdyn md_0814_0186.inp > md_0814_0186.log
time mpirun -np 16 $qdyn md_0800_0200.inp > md_0800_0200.log
time mpirun -np 16 $qdyn md_0786_0214.inp > md_0786_0214.log
time mpirun -np 16 $qdyn md_0771_0228.inp > md_0771_0228.log
time mpirun -np 16 $qdyn md_0757_0243.inp > md_0757_0243.log
time mpirun -np 16 $qdyn md_0743_0257.inp > md_0743_0257.log
time mpirun -np 16 $qdyn md_0728_0271.inp > md_0728_0271.log
time mpirun -np 16 $qdyn md_0714_0286.inp > md_0714_0286.log
time mpirun -np 16 $qdyn md_0700_0300.inp > md_0700_0300.log
time mpirun -np 16 $qdyn md_0685_0314.inp > md_0685_0314.log
time mpirun -np 16 $qdyn md_0671_0328.inp > md_0671_0328.log
time mpirun -np 16 $qdyn md_0657_0343.inp > md_0657_0343.log
time mpirun -np 16 $qdyn md_0643_0357.inp > md_0643_0357.log
time mpirun -np 16 $qdyn md_0628_0371.inp > md_0628_0371.log
time mpirun -np 16 $qdyn md_0614_0385.inp > md_0614_0385.log
time mpirun -np 16 $qdyn md_0600_0400.inp > md_0600_0400.log
time mpirun -np 16 $qdyn md_0585_0414.inp > md_0585_0414.log
time mpirun -np 16 $qdyn md_0571_0428.inp > md_0571_0428.log
time mpirun -np 16 $qdyn md_0557_0443.inp > md_0557_0443.log
time mpirun -np 16 $qdyn md_0543_0457.inp > md_0543_0457.log
time mpirun -np 16 $qdyn md_0528_0471.inp > md_0528_0471.log
time mpirun -np 16 $qdyn md_0514_0485.inp > md_0514_0485.log
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log
time mpirun -np 16 $qdyn md_0485_0514.inp > md_0485_0514.log
time mpirun -np 16 $qdyn md_0471_0528.inp > md_0471_0528.log
time mpirun -np 16 $qdyn md_0457_0543.inp > md_0457_0543.log
time mpirun -np 16 $qdyn md_0443_0557.inp > md_0443_0557.log
time mpirun -np 16 $qdyn md_0428_0571.inp > md_0428_0571.log
time mpirun -np 16 $qdyn md_0414_0585.inp > md_0414_0585.log
time mpirun -np 16 $qdyn md_0400_0600.inp > md_0400_0600.log
time mpirun -np 16 $qdyn md_0385_0614.inp > md_0385_0614.log
time mpirun -np 16 $qdyn md_0371_0628.inp > md_0371_0628.log
time mpirun -np 16 $qdyn md_0357_0643.inp > md_0357_0643.log
time mpirun -np 16 $qdyn md_0343_0657.inp > md_0343_0657.log
time mpirun -np 16 $qdyn md_0328_0671.inp > md_0328_0671.log
time mpirun -np 16 $qdyn md_0314_0685.inp > md_0314_0685.log
time mpirun -np 16 $qdyn md_0300_0700.inp > md_0300_0700.log
time mpirun -np 16 $qdyn md_0286_0714.inp > md_0286_0714.log
time mpirun -np 16 $qdyn md_0271_0728.inp > md_0271_0728.log
time mpirun -np 16 $qdyn md_0257_0743.inp > md_0257_0743.log
time mpirun -np 16 $qdyn md_0243_0757.inp > md_0243_0757.log
time mpirun -np 16 $qdyn md_0228_0771.inp > md_0228_0771.log
time mpirun -np 16 $qdyn md_0214_0786.inp > md_0214_0786.log
time mpirun -np 16 $qdyn md_0200_0800.inp > md_0200_0800.log
time mpirun -np 16 $qdyn md_0186_0814.inp > md_0186_0814.log
time mpirun -np 16 $qdyn md_0171_0828.inp > md_0171_0828.log
time mpirun -np 16 $qdyn md_0157_0843.inp > md_0157_0843.log
time mpirun -np 16 $qdyn md_0143_0857.inp > md_0143_0857.log
time mpirun -np 16 $qdyn md_0128_0871.inp > md_0128_0871.log
time mpirun -np 16 $qdyn md_0114_0886.inp > md_0114_0886.log
time mpirun -np 16 $qdyn md_0100_0900.inp > md_0100_0900.log
time mpirun -np 16 $qdyn md_0086_0914.inp > md_0086_0914.log
time mpirun -np 16 $qdyn md_0071_0929.inp > md_0071_0929.log
time mpirun -np 16 $qdyn md_0057_0943.inp > md_0057_0943.log
time mpirun -np 16 $qdyn md_0043_0957.inp > md_0043_0957.log
time mpirun -np 16 $qdyn md_0029_0971.inp > md_0029_0971.log
time mpirun -np 16 $qdyn md_0014_0986.inp > md_0014_0986.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log
timeout 30s /home/wjespers/software/Q/bin/qfep < qfep.inp > qfep.out
done
