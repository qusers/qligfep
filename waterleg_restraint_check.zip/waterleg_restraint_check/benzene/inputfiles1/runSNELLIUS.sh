#!/bin/bash
#
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#              d-hh:mm:ss
#SBATCH --time=0-12:00:00

export TMP=/tmp
export TEMP=/tmp
export TMPDIR=/tmp
## Load modules for qdynp
module load 2023 iimpi/2023a

## define qdynp location
qdyn=/home/wjespers/software/Q/bin/qdynp
fepfiles=(FEP1.fep)
temperature=298
run=10
finalMDrestart=md_0000_1000.re

workdir=/data1/s2904160/software_qligfep/indene_softcore_both_directions/protein_leg
inputfiles=/data1/s2904160/software_qligfep/indene_softcore_both_directions/protein_leg/inputfiles2
fepfile=FEP1.fep
fepdir=$workdir/FEP1
mkdir -p $fepdir
cd $fepdir
tempdir=$fepdir/$temperature
mkdir -p $tempdir
cd $tempdir

rundir=$tempdir/$run
mkdir -p $rundir
cd $rundir

cp $inputfiles/md*.inp .
cp $inputfiles/*.top .
cp $inputfiles/qfep1.inp .
cp $inputfiles/$fepfile .

cp $inputfiles/eq*.inp .
sed -i s/SEED_VAR/"$[1 + $[RANDOM % 9999]]"/ eq1.inp

sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp

#EQ_FILES
time mpirun -np 24 $qdyn eq1.inp > eq1.log
time mpirun -np 24 $qdyn eq2.inp > eq2.log
time mpirun -np 24 $qdyn eq3.inp > eq3.log
time mpirun -np 24 $qdyn eq4.inp > eq4.log
time mpirun -np 24 $qdyn eq5.inp > eq5.log

#RUN_FILES
time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log
time mpirun -np 16 $qdyn md_0750_0250.inp > md_0750_0250.log
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log
time mpirun -np 16 $qdyn md_0250_0750.inp > md_0250_0750.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log
timeout 30s /home/wjespers/software/Q/bin/qfep < qfep1.inp > qfep1.out
done