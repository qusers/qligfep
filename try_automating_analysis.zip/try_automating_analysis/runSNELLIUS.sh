#!/bin/bash
#
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#              d-hh:mm:ss
#SBATCH --time=0-12:00:00

export TMP=/tmp
export TEMP=/tmp
export TMPDIR=/tmp
## Load modules for qdynp
module load 2023 iimpi/2023a

vdW_leg() {
local index=$1
cp $inputfiles/mdfiles$index/eq*.inp .
sed -i s/SEED_VAR/"$[1 + $[RANDOM % 9999]]"/ eq1.inp
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp
cd ../../../../..
python retreive_dG_BAR_and_restraints.py -F protein_restraint_scheme/benzofuran/FEP1
python check_angle.py -F protein_restraint_scheme/benzofuran/FEP1 -I inputfiles_softcore_check/benzofuran -FF OPLS2005
}

softcore_leg() {
local index=$1
lastfep=FEP$((index-1))
cp $workdir/$lastfep/$temperature/$run/$finalMDrestart $rundir/eq5.re
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp
cd ../../../../..
python retreive_dG_BAR_and_restraints.py -F protein_restraint_scheme/benzofuran/FEP2
}

charge_leg() {
local index=$1
lastfep=FEP$((index-1))
cp $workdir/$lastfep/$temperature/$run/$finalMDrestart $rundir/eq5.re
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp
cd ../../../../..
python retreive_dG_BAR_and_restraints.py -F protein_restraint_scheme/benzofuran/FEP3
}

## define qdynp location
qdyn=/home/wjespers/software/Q/bin/qdynp
fepfiles=("FEP1.fep" "FEP2.fep" "FEP3.fep")
temperature=298
run=10
finalMDrestart=md_0000_1000.re

workdir=/gpfs/scratch1/nodespecific/int6/yricky/softcore_with_long_endpoint_sampling/butylbenzene_flag_0_seq5_soft5_15_radius_eq_15
inputfiles=/gpfs/scratch1/nodespecific/int6/yricky/softcore_with_long_endpoint_sampling/butylbenzene_flag_0_seq5_soft5_15_radius_eq_15/inputfiles

for ((index=1; index<=${#fepfiles[@]}; index++)); do
# do this for every FEP file, use index in the list.

fepfile=FEP$index.fep
fepstep=FEP$index
fepdir=$workdir/FEP$index
cd $fepdir
tempdir=$fepdir/$temperature
cd $tempdir
mdfilesdir=$inputfiles/mdfiles$index
rundir=$tempdir/$run
cd $rundir

cp $mdfilesdir/md*.inp .
cp $inputfiles/*.top .
cp $inputfiles/qfep$index.inp .
cp $inputfiles/$fepfile .

# Run the appropriate job function based on the filename
if [ "$fepstep" == "FEP1" ]; then
vdW_leg $index
elif [ "$fepstep" == "FEP2" ]; then
softcore_leg $index
elif [ "$fepstep" == "FEP3" ]; then
charge_leg $index
fi

done