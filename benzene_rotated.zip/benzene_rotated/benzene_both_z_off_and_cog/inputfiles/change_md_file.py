import os

directories = os.listdir('.')

# inputs = []

# for dirr in directories:
#     if dirr[:2] == 'md':
#         dirrr = dirr.strip('inp') + 'en'
#         inputs.append(dirrr)

# for i in reversed(inputs):
    # print(i)
    # print('time mpirun -np 16 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))

for dirr in directories:
    # print(dirr)
    if dirr[0:7] == "mdfiles":
        for mdfiles in os.listdir(dirr):
            # print(mdfiles)

            if mdfiles[:2] == 'md' or mdfiles[:2] == "eq":
                newfilelines = []
                with open(dirr + "/" + mdfiles) as mdfile:
                    for line in mdfile:
                        # newfilelines.append(line)
                        if '[sequence_restraints]' in line:
                            if mdfiles[:3] == "eq1" or mdfiles[:3] == "eq2":
                                    newfilelines.append(line)
                                    newfilelines.append('2597   2608   10.0 0  0\n\n')
                                    newfilelines.append('[distance_restraints]\n')
                            else:
                                newfilelines.append(line)
                                newfilelines.append('2597   2608    5.0 0  1\n\n')
                                newfilelines.append('[atom_restraints]\n')
                                newfilelines.append('2597 -0.149 -1.376 -0.027 5. 5. 0 0\n')
                                newfilelines.append('2598 1.125 -0.824 -0.027 5. 5. 0 0\n')
                                newfilelines.append('2599 1.279 0.556 -0.027 5. 5. 0 0\n')
                                newfilelines.append('2600 0.152 1.376 0.012 5. 5. 0 0\n')
                                newfilelines.append('2601 -1.130 0.825 0.056 5. 5. 0 0\n')
                                newfilelines.append('2602 -1.277 -0.557 0.012 5. 5. 0 0\n\n')
                                newfilelines.append('[distance_restraints]\n')
                            break
                        else:
                            newfilelines.append(line)

                    with open(dirr + "/" + mdfiles, 'w') as new:
                        for line in newfilelines:
                            new.write(line)