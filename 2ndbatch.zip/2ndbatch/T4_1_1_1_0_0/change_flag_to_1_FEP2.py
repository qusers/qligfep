import os

directories = os.listdir('.')

# inputs = []

# for dirr in directories:
#     if dirr[:2] == 'md':
#         dirrr = dirr.strip('inp') + 'en'
#         inputs.append(dirrr)

# for i in reversed(inputs):
    # print(i)
    # print('time mpirun -np 16 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))
for dirrr in directories:
    if os.path.isdir(dirrr):
        directories2 = os.listdir(dirrr + "/inputfiles/mdfiles2")
        for file in directories2:
            if file[:2] == 'md':
                newfilelines = []
                with open(dirrr + "/inputfiles/mdfiles2/" + file) as mdfile:
                    for mdfile_lines in mdfile:
                        if mdfile_lines[:4] == '2597':
                            # print(mdfile_lines)
                            # print(mdfile_lines[:-2] + "1\n")
                            newfilelines.append(mdfile_lines[:-2] + "1\n")
                        else:
                            newfilelines.append(mdfile_lines)

            with open(dirrr + "/inputfiles/mdfiles2/" + file, 'w') as new:
                for line in newfilelines:
                    new.write(line)
