import os
import subprocess

directories = os.listdir('.')

for dirr in directories:
    if os.path.isdir(dirr):
        files_in_dir = os.listdir(dirr)
        os.chdir(dirr)
        if "FEP_submit.sh" in files_in_dir:
            subprocess.call(['sh', 'FEP_submit.sh'])
            os.chdir("..")
