#!/bin/bash
#
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#              d-hh:mm:ss
#SBATCH --time=0-12:00:00

export TMP=/tmp
export TEMP=/tmp
export TMPDIR=/tmp
## Load modules for qdynp
module load 2023 iimpi/2023a

## define qdynp location
qdyn=/home/wjespers/software/Q/bin/qdynp
fepfiles=("FEP1.fep" "FEP2.fep" "FEP3.fep")
temperature=298
run=10
finalMDrestart=md_0000_1000.re

workdir=/gpfs/scratch1/nodespecific/int6/yricky/softcore_with_long_endpoint_sampling/
inputfiles=/gpfs/scratch1/nodespecific/int6/yricky/softcore_with_long_endpoint_sampling/

cd /gpfs/scratch1/nodespecific/int6/yricky

~/anaconda3/envs/QligFEP/bin/python analysis.py -F 2ndbatch/T4_0_0_0_0_0/dichlorobenzene1/FEP1 -FF OPLS2005 -I inputfiles_softcore_check/dichlorobenzene1 -convert
~/anaconda3/envs/QligFEP/bin/python analysis.py -F 2ndbatch/T4_0_0_0_0_0/dichlorobenzene1/FEP2 -FF OPLS2005 -I inputfiles_softcore_check/dichlorobenzene1 -convert
~/anaconda3/envs/QligFEP/bin/python analysis.py -F 2ndbatch/T4_0_0_0_0_0/dichlorobenzene1/FEP3 -FF OPLS2005 -I inputfiles_softcore_check/dichlorobenzene1 -convert