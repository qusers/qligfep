import os

directories = os.listdir('.')

# inputs = []

# for dirr in directories:
#     if dirr[:2] == 'md':
#         dirrr = dirr.strip('inp') + 'en'
#         inputs.append(dirrr)

# for i in reversed(inputs):
    # print(i)
    # print('time mpirun -np 16 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))

for dirr in directories:
    # print(dirr)
    if dirr[0:7] == "mdfiles":
        for mdfiles in os.listdir(dirr):
            # print(mdfiles)

            if mdfiles[:2] == 'md' or mdfiles[:2] == "eq":
                newfilelines = []
                with open(dirr + "/" + mdfiles) as mdfile:
                    for line in mdfile:
                        # newfilelines.append(line)
                        if '[sequence_restraints]' in line:
                            if mdfiles[:3] == "eq1" or mdfiles[:3] == "eq2":
                                    newfilelines.append(line)
                                    newfilelines.append('2597   2614   10.0 0  0\n\n')
                                    newfilelines.append('[distance_restraints]\n')
                            else:
                                newfilelines.append(line)
                                newfilelines.append('2597   2614    5.0 0  1\n\n')
                                newfilelines.append('[atom_restraints]\n')
                                newfilelines.append('2598 1.349 0.332 0.045 5. 5. 0 0\n')
                                newfilelines.append('2599 0.411 1.322 0.045 5. 5. 0 0\n')
                                newfilelines.append('2600 0.951 -0.993 0.045 5. 5. 0 0\n')
                                newfilelines.append('2601 -0.957 0.989 0.005 5. 5. 0 0\n')
                                newfilelines.append('2602 -0.407 -1.320 -0.048 5. 5. 0 0\n')
                                newfilelines.append('2603 -1.347 -0.331 -0.091 5. 5. 0 0\n\n')
                                newfilelines.append('[distance_restraints]\n')
                            break
                        else:
                            newfilelines.append(line)

                    with open(dirr + "/" + mdfiles, 'w') as new:
                        for line in newfilelines:
                            new.write(line)
