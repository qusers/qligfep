#!/bin/bash
#
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#              d-hh:mm:ss
#SBATCH --time=0-12:00:00

export TMP=/tmp
export TEMP=/tmp
export TMPDIR=/tmp
## Load modules for qdynp
module load 2023 iimpi/2023a

charge_leg() {
local index=$1
cp $inputfiles/mdfiles$index/eq*.inp .
sed -i s/SEED_VAR/"$[1 + $[RANDOM % 9999]]"/ eq1.inp
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp

#EQ_FILES
time mpirun -np 16 $qdyn eq1.inp > eq1.log
time mpirun -np 16 $qdyn eq2.inp > eq2.log
time mpirun -np 16 $qdyn eq3.inp > eq3.log
time mpirun -np 16 $qdyn eq4.inp > eq4.log
time mpirun -np 16 $qdyn eq5.inp > eq5.log

#RUN_FILES
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log

time mpirun -np 16 $qdyn md_0514_0485.inp > md_0514_0485.log
time mpirun -np 16 $qdyn md_0485_0514.inp > md_0485_0514.log

time mpirun -np 16 $qdyn md_0528_0471.inp > md_0528_0471.log
time mpirun -np 16 $qdyn md_0471_0528.inp > md_0471_0528.log

time mpirun -np 16 $qdyn md_0543_0457.inp > md_0543_0457.log
time mpirun -np 16 $qdyn md_0457_0543.inp > md_0457_0543.log

time mpirun -np 16 $qdyn md_0557_0443.inp > md_0557_0443.log
time mpirun -np 16 $qdyn md_0443_0557.inp > md_0443_0557.log

time mpirun -np 16 $qdyn md_0571_0428.inp > md_0571_0428.log
time mpirun -np 16 $qdyn md_0428_0571.inp > md_0428_0571.log

time mpirun -np 16 $qdyn md_0585_0414.inp > md_0585_0414.log
time mpirun -np 16 $qdyn md_0414_0585.inp > md_0414_0585.log

time mpirun -np 16 $qdyn md_0600_0400.inp > md_0600_0400.log
time mpirun -np 16 $qdyn md_0400_0600.inp > md_0400_0600.log

time mpirun -np 16 $qdyn md_0614_0385.inp > md_0614_0385.log
time mpirun -np 16 $qdyn md_0385_0614.inp > md_0385_0614.log

time mpirun -np 16 $qdyn md_0628_0371.inp > md_0628_0371.log
time mpirun -np 16 $qdyn md_0371_0628.inp > md_0371_0628.log

time mpirun -np 16 $qdyn md_0643_0357.inp > md_0643_0357.log
time mpirun -np 16 $qdyn md_0357_0643.inp > md_0357_0643.log

time mpirun -np 16 $qdyn md_0657_0343.inp > md_0657_0343.log
time mpirun -np 16 $qdyn md_0343_0657.inp > md_0343_0657.log

time mpirun -np 16 $qdyn md_0671_0328.inp > md_0671_0328.log
time mpirun -np 16 $qdyn md_0328_0671.inp > md_0328_0671.log

time mpirun -np 16 $qdyn md_0685_0314.inp > md_0685_0314.log
time mpirun -np 16 $qdyn md_0314_0685.inp > md_0314_0685.log

time mpirun -np 16 $qdyn md_0700_0300.inp > md_0700_0300.log
time mpirun -np 16 $qdyn md_0300_0700.inp > md_0300_0700.log

time mpirun -np 16 $qdyn md_0714_0286.inp > md_0714_0286.log
time mpirun -np 16 $qdyn md_0286_0714.inp > md_0286_0714.log

time mpirun -np 16 $qdyn md_0728_0271.inp > md_0728_0271.log
time mpirun -np 16 $qdyn md_0271_0728.inp > md_0271_0728.log

time mpirun -np 16 $qdyn md_0743_0257.inp > md_0743_0257.log
time mpirun -np 16 $qdyn md_0257_0743.inp > md_0257_0743.log

time mpirun -np 16 $qdyn md_0757_0243.inp > md_0757_0243.log
time mpirun -np 16 $qdyn md_0243_0757.inp > md_0243_0757.log

time mpirun -np 16 $qdyn md_0771_0228.inp > md_0771_0228.log
time mpirun -np 16 $qdyn md_0228_0771.inp > md_0228_0771.log

time mpirun -np 16 $qdyn md_0786_0214.inp > md_0786_0214.log
time mpirun -np 16 $qdyn md_0214_0786.inp > md_0214_0786.log

time mpirun -np 16 $qdyn md_0800_0200.inp > md_0800_0200.log
time mpirun -np 16 $qdyn md_0200_0800.inp > md_0200_0800.log

time mpirun -np 16 $qdyn md_0814_0186.inp > md_0814_0186.log
time mpirun -np 16 $qdyn md_0186_0814.inp > md_0186_0814.log

time mpirun -np 16 $qdyn md_0828_0171.inp > md_0828_0171.log
time mpirun -np 16 $qdyn md_0171_0828.inp > md_0171_0828.log

time mpirun -np 16 $qdyn md_0843_0157.inp > md_0843_0157.log
time mpirun -np 16 $qdyn md_0157_0843.inp > md_0157_0843.log

time mpirun -np 16 $qdyn md_0857_0143.inp > md_0857_0143.log
time mpirun -np 16 $qdyn md_0143_0857.inp > md_0143_0857.log

time mpirun -np 16 $qdyn md_0871_0128.inp > md_0871_0128.log
time mpirun -np 16 $qdyn md_0128_0871.inp > md_0128_0871.log

time mpirun -np 16 $qdyn md_0886_0114.inp > md_0886_0114.log
time mpirun -np 16 $qdyn md_0114_0886.inp > md_0114_0886.log

time mpirun -np 16 $qdyn md_0900_0100.inp > md_0900_0100.log
time mpirun -np 16 $qdyn md_0100_0900.inp > md_0100_0900.log

time mpirun -np 16 $qdyn md_0914_0086.inp > md_0914_0086.log
time mpirun -np 16 $qdyn md_0086_0914.inp > md_0086_0914.log

time mpirun -np 16 $qdyn md_0929_0071.inp > md_0929_0071.log
time mpirun -np 16 $qdyn md_0071_0929.inp > md_0071_0929.log

time mpirun -np 16 $qdyn md_0943_0057.inp > md_0943_0057.log
time mpirun -np 16 $qdyn md_0057_0943.inp > md_0057_0943.log

time mpirun -np 16 $qdyn md_0957_0043.inp > md_0957_0043.log
time mpirun -np 16 $qdyn md_0043_0957.inp > md_0043_0957.log

time mpirun -np 16 $qdyn md_0971_0029.inp > md_0971_0029.log
time mpirun -np 16 $qdyn md_0029_0971.inp > md_0029_0971.log

time mpirun -np 16 $qdyn md_0986_0014.inp > md_0986_0014.log
time mpirun -np 16 $qdyn md_0014_0986.inp > md_0014_0986.log

time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log

timeout 30s /home/wjespers/software/Q/bin/qfep < qfep1.inp > qfep1.out
rm *.dcd
rm *.en
}

softcore_leg() {
local index=$1
lastfep=FEP$((index-1))
cp $workdir/$lastfep/$temperature/$run/$finalMDrestart $rundir/eq5.re
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp
#RUN_FILES
time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log
time mpirun -np 16 $qdyn md_0980_0020.inp > md_0980_0020.log
time mpirun -np 16 $qdyn md_0960_0040.inp > md_0960_0040.log
time mpirun -np 16 $qdyn md_0940_0060.inp > md_0940_0060.log
time mpirun -np 16 $qdyn md_0920_0080.inp > md_0920_0080.log
time mpirun -np 16 $qdyn md_0900_0100.inp > md_0900_0100.log
time mpirun -np 16 $qdyn md_0880_0120.inp > md_0880_0120.log
time mpirun -np 16 $qdyn md_0860_0140.inp > md_0860_0140.log
time mpirun -np 16 $qdyn md_0840_0160.inp > md_0840_0160.log
time mpirun -np 16 $qdyn md_0820_0180.inp > md_0820_0180.log
time mpirun -np 16 $qdyn md_0800_0200.inp > md_0800_0200.log
time mpirun -np 16 $qdyn md_0780_0220.inp > md_0780_0220.log
time mpirun -np 16 $qdyn md_0760_0240.inp > md_0760_0240.log
time mpirun -np 16 $qdyn md_0740_0260.inp > md_0740_0260.log
time mpirun -np 16 $qdyn md_0720_0280.inp > md_0720_0280.log
time mpirun -np 16 $qdyn md_0700_0300.inp > md_0700_0300.log
time mpirun -np 16 $qdyn md_0680_0320.inp > md_0680_0320.log
time mpirun -np 16 $qdyn md_0660_0340.inp > md_0660_0340.log
time mpirun -np 16 $qdyn md_0640_0360.inp > md_0640_0360.log
time mpirun -np 16 $qdyn md_0620_0380.inp > md_0620_0380.log
time mpirun -np 16 $qdyn md_0600_0400.inp > md_0600_0400.log
time mpirun -np 16 $qdyn md_0580_0420.inp > md_0580_0420.log
time mpirun -np 16 $qdyn md_0560_0440.inp > md_0560_0440.log
time mpirun -np 16 $qdyn md_0540_0460.inp > md_0540_0460.log
time mpirun -np 16 $qdyn md_0520_0480.inp > md_0520_0480.log
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log
time mpirun -np 16 $qdyn md_0480_0520.inp > md_0480_0520.log
time mpirun -np 16 $qdyn md_0460_0540.inp > md_0460_0540.log
time mpirun -np 16 $qdyn md_0440_0560.inp > md_0440_0560.log
time mpirun -np 16 $qdyn md_0420_0580.inp > md_0420_0580.log
time mpirun -np 16 $qdyn md_0400_0600.inp > md_0400_0600.log
time mpirun -np 16 $qdyn md_0380_0620.inp > md_0380_0620.log
time mpirun -np 16 $qdyn md_0360_0640.inp > md_0360_0640.log
time mpirun -np 16 $qdyn md_0340_0660.inp > md_0340_0660.log
time mpirun -np 16 $qdyn md_0320_0680.inp > md_0320_0680.log
time mpirun -np 16 $qdyn md_0300_0700.inp > md_0300_0700.log
time mpirun -np 16 $qdyn md_0280_0720.inp > md_0280_0720.log
time mpirun -np 16 $qdyn md_0260_0740.inp > md_0260_0740.log
time mpirun -np 16 $qdyn md_0240_0760.inp > md_0240_0760.log
time mpirun -np 16 $qdyn md_0220_0780.inp > md_0220_0780.log
time mpirun -np 16 $qdyn md_0200_0800.inp > md_0200_0800.log
time mpirun -np 16 $qdyn md_0180_0820.inp > md_0180_0820.log
time mpirun -np 16 $qdyn md_0160_0840.inp > md_0160_0840.log
time mpirun -np 16 $qdyn md_0140_0860.inp > md_0140_0860.log
time mpirun -np 16 $qdyn md_0120_0880.inp > md_0120_0880.log
time mpirun -np 16 $qdyn md_0100_0900.inp > md_0100_0900.log
time mpirun -np 16 $qdyn md_0080_0920.inp > md_0080_0920.log
time mpirun -np 16 $qdyn md_0060_0940.inp > md_0060_0940.log
time mpirun -np 16 $qdyn md_0040_0960.inp > md_0040_0960.log
time mpirun -np 16 $qdyn md_0020_0980.inp > md_0020_0980.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log
timeout 30s /home/wjespers/software/Q/bin/qfep < qfep2.inp > qfep2.out
rm *.dcd
rm *.en
}

vdW_leg() {
local index=$1
lastfep=FEP$((index-1))
cp $workdir/$lastfep/$temperature/$run/$finalMDrestart $rundir/eq5.re
sed -i s/T_VAR/"$temperature"/ *.inp
sed -i s/FEP_VAR/"$fepfile"/ *.inp
#RUN_FILES
time mpirun -np 16 $qdyn md_1000_0000.inp > md_1000_0000.log
time mpirun -np 16 $qdyn md_0986_0014.inp > md_0986_0014.log
time mpirun -np 16 $qdyn md_0971_0029.inp > md_0971_0029.log
time mpirun -np 16 $qdyn md_0957_0043.inp > md_0957_0043.log
time mpirun -np 16 $qdyn md_0943_0057.inp > md_0943_0057.log
time mpirun -np 16 $qdyn md_0929_0071.inp > md_0929_0071.log
time mpirun -np 16 $qdyn md_0914_0086.inp > md_0914_0086.log
time mpirun -np 16 $qdyn md_0900_0100.inp > md_0900_0100.log
time mpirun -np 16 $qdyn md_0886_0114.inp > md_0886_0114.log
time mpirun -np 16 $qdyn md_0871_0128.inp > md_0871_0128.log
time mpirun -np 16 $qdyn md_0857_0143.inp > md_0857_0143.log
time mpirun -np 16 $qdyn md_0843_0157.inp > md_0843_0157.log
time mpirun -np 16 $qdyn md_0828_0171.inp > md_0828_0171.log
time mpirun -np 16 $qdyn md_0814_0186.inp > md_0814_0186.log
time mpirun -np 16 $qdyn md_0800_0200.inp > md_0800_0200.log
time mpirun -np 16 $qdyn md_0786_0214.inp > md_0786_0214.log
time mpirun -np 16 $qdyn md_0771_0228.inp > md_0771_0228.log
time mpirun -np 16 $qdyn md_0757_0243.inp > md_0757_0243.log
time mpirun -np 16 $qdyn md_0743_0257.inp > md_0743_0257.log
time mpirun -np 16 $qdyn md_0728_0271.inp > md_0728_0271.log
time mpirun -np 16 $qdyn md_0714_0286.inp > md_0714_0286.log
time mpirun -np 16 $qdyn md_0700_0300.inp > md_0700_0300.log
time mpirun -np 16 $qdyn md_0685_0314.inp > md_0685_0314.log
time mpirun -np 16 $qdyn md_0671_0328.inp > md_0671_0328.log
time mpirun -np 16 $qdyn md_0657_0343.inp > md_0657_0343.log
time mpirun -np 16 $qdyn md_0643_0357.inp > md_0643_0357.log
time mpirun -np 16 $qdyn md_0628_0371.inp > md_0628_0371.log
time mpirun -np 16 $qdyn md_0614_0385.inp > md_0614_0385.log
time mpirun -np 16 $qdyn md_0600_0400.inp > md_0600_0400.log
time mpirun -np 16 $qdyn md_0585_0414.inp > md_0585_0414.log
time mpirun -np 16 $qdyn md_0571_0428.inp > md_0571_0428.log
time mpirun -np 16 $qdyn md_0557_0443.inp > md_0557_0443.log
time mpirun -np 16 $qdyn md_0543_0457.inp > md_0543_0457.log
time mpirun -np 16 $qdyn md_0528_0471.inp > md_0528_0471.log
time mpirun -np 16 $qdyn md_0514_0485.inp > md_0514_0485.log
time mpirun -np 16 $qdyn md_0500_0500.inp > md_0500_0500.log
time mpirun -np 16 $qdyn md_0485_0514.inp > md_0485_0514.log
time mpirun -np 16 $qdyn md_0471_0528.inp > md_0471_0528.log
time mpirun -np 16 $qdyn md_0457_0543.inp > md_0457_0543.log
time mpirun -np 16 $qdyn md_0443_0557.inp > md_0443_0557.log
time mpirun -np 16 $qdyn md_0428_0571.inp > md_0428_0571.log
time mpirun -np 16 $qdyn md_0414_0585.inp > md_0414_0585.log
time mpirun -np 16 $qdyn md_0400_0600.inp > md_0400_0600.log
time mpirun -np 16 $qdyn md_0385_0614.inp > md_0385_0614.log
time mpirun -np 16 $qdyn md_0371_0628.inp > md_0371_0628.log
time mpirun -np 16 $qdyn md_0357_0643.inp > md_0357_0643.log
time mpirun -np 16 $qdyn md_0343_0657.inp > md_0343_0657.log
time mpirun -np 16 $qdyn md_0328_0671.inp > md_0328_0671.log
time mpirun -np 16 $qdyn md_0314_0685.inp > md_0314_0685.log
time mpirun -np 16 $qdyn md_0300_0700.inp > md_0300_0700.log
time mpirun -np 16 $qdyn md_0286_0714.inp > md_0286_0714.log
time mpirun -np 16 $qdyn md_0271_0728.inp > md_0271_0728.log
time mpirun -np 16 $qdyn md_0257_0743.inp > md_0257_0743.log
time mpirun -np 16 $qdyn md_0243_0757.inp > md_0243_0757.log
time mpirun -np 16 $qdyn md_0228_0771.inp > md_0228_0771.log
time mpirun -np 16 $qdyn md_0214_0786.inp > md_0214_0786.log
time mpirun -np 16 $qdyn md_0200_0800.inp > md_0200_0800.log
time mpirun -np 16 $qdyn md_0186_0814.inp > md_0186_0814.log
time mpirun -np 16 $qdyn md_0171_0828.inp > md_0171_0828.log
time mpirun -np 16 $qdyn md_0157_0843.inp > md_0157_0843.log
time mpirun -np 16 $qdyn md_0143_0857.inp > md_0143_0857.log
time mpirun -np 16 $qdyn md_0128_0871.inp > md_0128_0871.log
time mpirun -np 16 $qdyn md_0114_0886.inp > md_0114_0886.log
time mpirun -np 16 $qdyn md_0100_0900.inp > md_0100_0900.log
time mpirun -np 16 $qdyn md_0087_0912.inp > md_0087_0912.log
time mpirun -np 16 $qdyn md_0075_0925.inp > md_0075_0925.log
time mpirun -np 16 $qdyn md_0062_0938.inp > md_0062_0938.log
time mpirun -np 16 $qdyn md_0053_0947.inp > md_0053_0947.log
time mpirun -np 16 $qdyn md_0045_0955.inp > md_0045_0955.log
time mpirun -np 16 $qdyn md_0038_0962.inp > md_0038_0962.log
time mpirun -np 16 $qdyn md_0033_0967.inp > md_0033_0967.log
time mpirun -np 16 $qdyn md_0031_0969.inp > md_0031_0969.log
time mpirun -np 16 $qdyn md_0029_0971.inp > md_0029_0971.log
time mpirun -np 16 $qdyn md_0026_0974.inp > md_0026_0974.log
time mpirun -np 16 $qdyn md_0024_0976.inp > md_0024_0976.log
time mpirun -np 16 $qdyn md_0022_0978.inp > md_0022_0978.log
time mpirun -np 16 $qdyn md_0021_0979.inp > md_0021_0979.log
time mpirun -np 16 $qdyn md_0019_0981.inp > md_0019_0981.log
time mpirun -np 16 $qdyn md_0017_0983.inp > md_0017_0983.log
time mpirun -np 16 $qdyn md_0015_0985.inp > md_0015_0985.log
time mpirun -np 16 $qdyn md_0014_0986.inp > md_0014_0986.log
time mpirun -np 16 $qdyn md_0012_0988.inp > md_0012_0988.log
time mpirun -np 16 $qdyn md_0011_0989.inp > md_0011_0989.log
time mpirun -np 16 $qdyn md_0010_0990.inp > md_0010_0990.log
time mpirun -np 16 $qdyn md_0009_0991.inp > md_0009_0991.log
time mpirun -np 16 $qdyn md_0008_0992.inp > md_0008_0992.log
time mpirun -np 16 $qdyn md_0007_0993.inp > md_0007_0993.log
time mpirun -np 16 $qdyn md_0006_0994.inp > md_0006_0994.log
time mpirun -np 16 $qdyn md_0005_0995.inp > md_0005_0995.log
time mpirun -np 16 $qdyn md_0004_0996.inp > md_0004_0996.log
time mpirun -np 16 $qdyn md_0003_0997.inp > md_0003_0997.log
time mpirun -np 16 $qdyn md_0002_0998.inp > md_0002_0998.log
time mpirun -np 16 $qdyn md_0001_0999.inp > md_0001_0999.log
time mpirun -np 16 $qdyn md_0000_1000.inp > md_0000_1000.log
timeout 30s /home/wjespers/software/Q/bin/qfep < qfep3.inp > qfep3.out
rm *.dcd
rm *.en
}

## define qdynp location
qdyn=/home/wjespers/software/Q/bin/qdynp
fepfiles=("FEP1.fep" "FEP2.fep" "FEP3.fep")
temperature=298
run=10
finalMDrestart=md_0000_1000.re

workdir=/data1/s2904160/software_qligfep/o_xylene_softcore_both_directions_more_windows/protein_leg
inputfiles=/data1/s2904160/software_qligfep/o_xylene_softcore_both_directions_more_windows/protein_leg/inputfiles1

for ((index=1; index<=${#fepfiles[@]}; index++)); do
# do this for every FEP file, use index in the list.

fepfile=FEP$index.fep
fepstep=FEP$index
fepdir=$workdir/FEP$index
mkdir -p $fepdir
cd $fepdir
tempdir=$fepdir/$temperature
mkdir -p $tempdir
cd $tempdir
mdfilesdir=$inputfiles/mdfiles$index
rundir=$tempdir/$run
mkdir -p $rundir
cd $rundir

cp $mdfilesdir/md*.inp .
cp $inputfiles/*.top .
cp $inputfiles/qfep$index.inp .
cp $inputfiles/$fepfile .

# Run the appropriate job function based on the filename
if [ "$fepstep" == "FEP1" ]; then
charge_leg $index
elif [ "$fepstep" == "FEP2" ]; then
softcore_leg $index
elif [ "$fepstep" == "FEP3" ]; then
vdW_leg $index
fi

done