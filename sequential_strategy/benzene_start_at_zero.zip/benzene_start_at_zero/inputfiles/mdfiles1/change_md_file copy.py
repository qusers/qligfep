import os

directories = os.listdir('.')

inputs = []

for dirr in directories:
    if dirr[:2] == 'md':
        dirrr = dirr.strip('inp') + 'en'
        inputs.append(dirrr)

for i in reversed(inputs):
    print(i)
    # print('time mpirun -np 24 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))

# def restraint(mdfile):
#     if mdfile == 757 or mdfile == 743 or mdfile == 728:
#         restraint = '2597   2608    4.0 0  0\n\n'
#     elif mdfile == 800 or mdfile == 786 or mdfile == 771:
#         restraint = '2597   2608    3.0 0  0\n\n'
#     elif mdfile == 843 or mdfile == 828 or mdfile == 814:
#         restraint = '2597   2608    2.0 0  0\n\n'
#     elif mdfile == 886 or mdfile == 871 or mdfile == 857:
#         restraint = '2597   2608    1.0 0  0\n\n'
#     elif mdfile >= 900:
#         restraint = '\n'
#     else:
#         restraint = '2597   2608    5.0 0  0\n\n'

#     return restraint

# for dirr in directories:
#     start = 0
#     # print(dirr)
#     if dirr[:2] == 'md' or dirr[:2] == "eq":
#         newfilelines = []
#         with open(dirr) as mdfile:
#             for line in mdfile:
#                 # newfilelines.append(line)
#                 if '[sequence_restraints]' in line:
#                     if dirr[:3] == "eq1" or dirr[:3] == "eq2":
#                         newfilelines.append(line)
#                         newfilelines.append('2597   2608   10.0 0  0\n\n')
#                         newfilelines.append('[distance_restraints]\n')
#                     elif dirr[:3] == "eq3" or dirr[:3] == "eq4" or dirr[:3] == "eq5":
#                         newfilelines.append(line)
#                         newfilelines.append('2597   2608    5.0 0  0\n\n')
#                         newfilelines.append('[distance_restraints]\n')
#                     else:
#                         # print(dirr)
#                         restr = restraint(int(dirr[3:7]))
#                         # print(restr)
#                         newfilelines.append(line)
#                         newfilelines.append(restr)
#                         newfilelines.append('[distance_restraints]\n')
#                     break
#                 else:
#                     newfilelines.append(line)

#             with open(dirr, 'w') as new:
#                 for line in newfilelines:
#                     new.write(line)