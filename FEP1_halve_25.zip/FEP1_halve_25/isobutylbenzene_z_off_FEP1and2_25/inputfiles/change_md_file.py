import os

directories = os.listdir('.')

# inputs = []

# for dirr in directories:
#     if dirr[:2] == 'md':
#         dirrr = dirr.strip('inp') + 'en'
#         inputs.append(dirrr)

# for i in reversed(inputs):
    # print(i)
    # print('time mpirun -np 16 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))

for dirr in directories:
    # print(dirr)
    if dirr[0:7] == "mdfiles":
        for mdfiles in os.listdir(dirr):
            # print(mdfiles)

            if mdfiles[:2] == 'md' or mdfiles[:2] == "eq":
                newfilelines = []
                with open(dirr + "/" + mdfiles) as mdfile:
                    for line in mdfile:
                        # newfilelines.append(line)
                        if '[sequence_restraints]' in line:
                            if mdfiles[:3] == "eq1" or mdfiles[:3] == "eq2":
                                    newfilelines.append(line)
                                    newfilelines.append('2597   2620   10.0 0  0\n\n')
                                    newfilelines.append('[distance_restraints]\n')
                            else:
                                newfilelines.append(line)
                                newfilelines.append('\n\n')
                                newfilelines.append('[atom_restraints]\n')
                                newfilelines.append('2601 1.377 0.206 0.012 5. 5. 0 0\n')
                                newfilelines.append('2602 0.526 1.284 0.012 5. 5. 0 0\n')
                                newfilelines.append('2603 -0.875 1.085 0.012 5. 5. 0 0\n')
                                newfilelines.append('2604 -1.380 -0.198 -0.039 5. 5. 0 0\n')
                                newfilelines.append('2605 -0.517 -1.289 -0.016 5. 5. 0 0\n')
                                newfilelines.append('2606 0.870 -1.087 0.021 5. 5. 0 0\n\n')
                                newfilelines.append('[distance_restraints]\n')
                            break
                        else:
                            newfilelines.append(line)

                    with open(dirr + "/" + mdfiles, 'w') as new:
                        for line in newfilelines:
                            new.write(line)
