import os

directories = os.listdir('mdfiles2')

for file in directories:
    if file[:2] == 'md':
        newfilelines = []
        with open("mdfiles2/" + file) as mdfile:
            for mdfile_lines in mdfile:
                if 'shell_radius' in mdfile_lines:
                    newfilelines.append("shell_radius              25")
                else:
                    newfilelines.append(mdfile_lines)

    with open("mdfiles2/" + file, 'w') as new:
        for line in newfilelines:
            new.write(line)