import os

directories = os.listdir('mdfiles1')

for file in directories:
    if file[:2] == 'md':
        newfilelines = []
        mdfile_lmda = (int(file[3:7]))
        if mdfile_lmda < 500:
            with open("mdfiles1/" + file) as mdfile:
                for mdfile_lines in mdfile:
                    if 'shell_radius' in mdfile_lines:
                        newfilelines.append("shell_radius              25\n")
                    else:
                        newfilelines.append(mdfile_lines)
        else:
            with open("mdfiles1/" + file) as mdfile:
                for mdfile_lines in mdfile:
                    if 'shell_radius' in mdfile_lines:
                        newfilelines.append("shell_radius              15\n")
                    else:
                        newfilelines.append(mdfile_lines)

        with open("mdfiles1/" + file, 'w') as new:
            for line in newfilelines:
                new.write(line)