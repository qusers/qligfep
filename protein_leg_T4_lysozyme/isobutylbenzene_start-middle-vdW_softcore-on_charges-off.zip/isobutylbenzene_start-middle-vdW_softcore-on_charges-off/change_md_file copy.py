import os

directories = os.listdir('.')

# inputs = []

# for dirr in directories:
#     if dirr[:2] == 'md':
#         dirrr = dirr.strip('inp') + 'en'
#         inputs.append(dirrr)

# for i in reversed(inputs):
#     print(i)
    # print('time mpirun -np 24 $qdyn ' + i + ' > ' + i.replace('.inp','.log'))

def restraint(mdfile):
    if mdfile == 240 or mdfile == 260:
        restraint = '2597   2611    4.0 0  0\n\n'
    elif mdfile == 200 or mdfile == 220:
        restraint = '2597   2611    3.0 0  0\n\n'
    elif mdfile == 160 or mdfile == 180:
        restraint = '2597   2611    2.0 0  0\n\n'
    elif mdfile == 120 or mdfile == 140:
        restraint = '2597   2611    1.0 0  0\n\n'
    elif mdfile <= 100:
        restraint = '\n'
    else:
        restraint = '2597   2611    5.0 0  0\n\n'

    return restraint

for dirr in directories:
    start = 0
    # print(dirr)
    if dirr[:2] == 'md':
        newfilelines = []
        with open(dirr) as mdfile:
                # print(restraint)
            for line in mdfile:
                # newfilelines.append(line)
                if '[sequence_restraints]' in line:
                    restr = restraint(int(dirr[3:7]))
                    # print(int(dirr[3:7]))
                    # print(restr)
                    # print(restr)
                    newfilelines.append(line)
                    newfilelines.append(restr)
                    # newfilelines.append('[distance_restraints]\n')
                    break
                else:
                    newfilelines.append(line)

            with open(dirr, 'w') as new:
                for line in newfilelines:
                    new.write(line)